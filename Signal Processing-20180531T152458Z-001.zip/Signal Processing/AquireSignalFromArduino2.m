clear; clc;
a = arduino('com7','nano');
figure
h = animatedline;
ax = gca;
ax.YGrid = 'on';
ax.YLim = [0 5];

stop = false;
startTime = datetime('now');
tic
while toc < 10
    v = readVoltage(a,'A1')
    t =  datetime('now') - startTime;
    addpoints(h,datenum(t),v)
    ax.XLim = datenum([t-seconds(15) t]);
    datetick('x','keeplimits')
    drawnow
end