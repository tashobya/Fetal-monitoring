%% Add the location of the working folder that contains +arduinoioaddons to the MATLAB path.
clear all; clc;
addpath ('C:\Users\hudso_000\Google Drive\Uganda Industrial Research Institute\wekebere electronic and hardware\Signal Processing');
%% Create an arduino object specifying the ExampleLCD/LCDAddon library. 
% Set ForceBuild to true to reprogram the board.
% a = arduino('com9','nano3','libraries','ExampleLCD/LCDAddon','ForceBuild',true);
a = arduino('COM7','NANO','libraries','ExampleLCD/LCDAddon','ForceBuild',true);
%% Create the LCD object, and specify the pins you configured on the Arduino device. 
lcd = addon(a,'ExampleLCD/LCDAddon',{'D12','D11','D5','D4','D3','D2'});

%% Initialize the LCD.
initializeLCD(lcd);

%% Print a string to the LCD.
printLCD(lcd,'WEKEBERE!');

%% Clear the LCD.
% clearLCD(lcd);
