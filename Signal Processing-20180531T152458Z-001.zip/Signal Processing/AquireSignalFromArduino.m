clear; clc;
raw = arduino('com7','nano');
tic
% start_time = tic;
for i = 1:10000
        voltage(i) = readVoltage(raw,'A1');
%         pause (1/1000)
%         plot (voltage)
%         toc
end
number_of_samples = length(voltage);
toc;
% elapsed = last_time-start_time;
sound(voltage,1000);
% p = audioplayer(voltage, 100);
% plot (voltage)