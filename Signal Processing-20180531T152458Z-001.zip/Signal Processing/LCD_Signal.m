%% Add the location of the working folder that contains +arduinoioaddons to the MATLAB path.
clear all; clc; warning off;
addpath ('C:\Users\hudso_000\Google Drive\Uganda Industrial Research Institute\wekebere electronic and hardware\Signal Processing');
%% Create an arduino object specifying the ExampleLCD/LCDAddon library. 
% Set ForceBuild to true to reprogram the board.
% a = arduino('com9','nano3','libraries','ExampleLCD/LCDAddon','ForceBuild',true);
a = arduino('COM7','NANO','libraries','ExampleLCD/LCDAddon','ForceBuild',true);
%% Create the LCD object, and specify the pins you configured on the Arduino device. 
lcd = addon(a,'ExampleLCD/LCDAddon',{'D12','D11','D5','D4','D3','D2'});

%% Initialize the LCD.
initializeLCD(lcd);

%% Print a string to the LCD.
writeDigitalPin(a,'D9',1);
printLCD(lcd,'WELCOME TO');
printLCD(lcd,' WEKEBERE');
pause(5);
writeDigitalPin(a,'D9',0);
%% Clear the LCD.
% clearLCD(lcd);
figure
h = animatedline;
ax = gca;
ax.YGrid = 'on';
ax.YLim = [0 5];

stop = false;
startTime = datetime('now');
tic
while toc < 10
    clearLCD(lcd);
    %% FHR
    FHRread = round(readVoltage(a,'A1'),4);
    FHRPrintn2s = num2str(FHRread);
    FHRPrintstc = strcat('FHR: ',FHRPrintn2s,' BPM');
    printLCD(lcd,FHRPrintstc);
    %% Cont
    CONTread = round(readVoltage(a,'A0'),4);
    CONTPrintn2s = num2str(CONTread);
    CONTPrintstc = strcat('CON: ',CONTPrintn2s);
    printLCD(lcd,CONTPrintstc);
    t =  datetime('now') - startTime;
    addpoints(h,datenum(t),FHRread)
    ax.XLim = datenum([t-seconds(15) t]);
    datetick('x','keeplimits')
    drawnow
end