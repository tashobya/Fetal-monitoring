clear; clc;
raw = arduino('com7','nano');
i = 0;
tic;
while toc < 10
    i = i+1;
    voltage(i) = readVoltage(raw,'A1');
    t(i)=toc;
end

%% Compute the acquisition rate
timeBtnDataPoints = diff(t);
aveTimePerDataPt = mean(timeBtnDataPoints);
dataRateHz =  1/aveTimePerDataPt;